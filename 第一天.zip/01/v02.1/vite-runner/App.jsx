// js pragma
/**@jsx CReact.createElement */
import CReact from "./core/React.js";
const App = <div>hi-mini-react</div>;

// function AppOne() {
//   return <div>hi-mini-react</div>;
// }

// console.log(AppOne)

export default App;
