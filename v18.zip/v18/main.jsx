import React from './core/React.js';
import ReactDOM from "./core/ReactDom.js";
import App from "./App.jsx";
import Tapp from './Tapp.jsx';

// ReactDOM.createRoot(document.querySelector("#root")).render(<App></App>);
ReactDOM.createRoot(document.querySelector("#root")).render(<Tapp></Tapp>);
